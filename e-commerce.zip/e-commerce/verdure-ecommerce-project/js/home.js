/* =========================================================
   VERDURE — HOMEPAGE SCRIPT
   Renders featured products and drives the testimonial slider.
   (productCardHTML / attachProductCardEvents live in ui.js
   so they can be shared with the shop and product pages.)
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  renderFeaturedProducts();
  initTestimonialSlider();
});

function renderFeaturedProducts() {
  const wrap = document.getElementById("featuredProducts");
  if (!wrap) return;

  const featured = PRODUCTS.slice(0, 8);
  wrap.innerHTML = featured.map(productCardHTML).join("");
  attachProductCardEvents(wrap);
}

/* -------------------- TESTIMONIAL SLIDER -------------------- */
function initTestimonialSlider() {
  const track = document.getElementById("testimonialTrack");
  const dotsWrap = document.getElementById("testimonialDots");
  if (!track || !dotsWrap) return;

  const cards = track.querySelectorAll(".testimonial-card");
  const perView = window.innerWidth <= 760 ? 1 : (window.innerWidth <= 980 ? 2 : 3);
  const totalSlides = Math.max(1, cards.length - perView + 1);
  let current = 0;

  dotsWrap.innerHTML = "";
  for (let i = 0; i < totalSlides; i++) {
    const dot = document.createElement("button");
    dot.className = "slider-dot" + (i === 0 ? " is-active" : "");
    dot.addEventListener("click", function () {
      goTo(i);
    });
    dotsWrap.appendChild(dot);
  }

  function goTo(index) {
    current = index;
    const cardWidth = cards[0].getBoundingClientRect().width;
    const gapPx = 24;
    track.style.transform = "translateX(-" + (index * (cardWidth + gapPx)) + "px)";
    dotsWrap.querySelectorAll(".slider-dot").forEach(function (d, i) {
      d.classList.toggle("is-active", i === index);
    });
  }

  let autoTimer = setInterval(function () {
    current = (current + 1) % totalSlides;
    goTo(current);
  }, 4500);

  track.parentElement.addEventListener("mouseenter", function () {
    clearInterval(autoTimer);
  });
  track.parentElement.addEventListener("mouseleave", function () {
    autoTimer = setInterval(function () {
      current = (current + 1) % totalSlides;
      goTo(current);
    }, 4500);
  });
}
