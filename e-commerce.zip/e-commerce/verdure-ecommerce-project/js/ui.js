/* =========================================================
   VERDURE — SHARED UI BEHAVIOUR (runs on every page)
   Handles: header badge counts, mini-cart drawer, mobile nav,
   toast messages, and the newsletter form in the footer.
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  refreshHeaderCounts();
  initMobileMenu();
  initMiniCart();
  initNewsletterForm();
  renderMiniCartItems();
});

/* -------------------- HEADER BADGE COUNTS -------------------- */
function refreshHeaderCounts() {
  const cartCountEl = document.getElementById("cartCount");
  const wishlistCountEl = document.getElementById("wishlistCount");
  if (cartCountEl) {
    cartCountEl.textContent = Cart.count();
  }
  if (wishlistCountEl) {
    wishlistCountEl.textContent = Wishlist.count();
  }
}

function bumpBadge(el) {
  if (!el) return;
  el.classList.remove("bump");
  /* forcing a reflow lets the animation replay on repeated clicks */
  void el.offsetWidth;
  el.classList.add("bump");
}

/* -------------------- MOBILE MENU -------------------- */
function initMobileMenu() {
  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("siteNav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", function () {
    toggle.classList.toggle("is-open");
    nav.classList.toggle("is-open");
  });
}

/* -------------------- MINI CART DRAWER -------------------- */
function initMiniCart() {
  const cartBtn = document.getElementById("cartBtn");
  const miniCart = document.getElementById("miniCart");
  const overlay = document.getElementById("miniCartOverlay");
  const closeBtn = document.getElementById("miniCartClose");
  if (!miniCart || !overlay) return;

  function openMiniCart() {
    renderMiniCartItems();
    miniCart.classList.add("is-open");
    overlay.classList.add("is-visible");
  }
  function closeMiniCart() {
    miniCart.classList.remove("is-open");
    overlay.classList.remove("is-visible");
  }

  if (cartBtn) {
    cartBtn.addEventListener("click", openMiniCart);
  }
  if (closeBtn) {
    closeBtn.addEventListener("click", closeMiniCart);
  }
  overlay.addEventListener("click", closeMiniCart);

  /* expose so other scripts (e.g. product page "Add to cart") can open it */
  window.openMiniCart = openMiniCart;
  window.closeMiniCart = closeMiniCart;
}

function renderMiniCartItems() {
  const wrap = document.getElementById("miniCartItems");
  const subtotalEl = document.getElementById("miniCartSubtotal");
  if (!wrap) return;

  const items = Cart.items();

  if (items.length === 0) {
    wrap.innerHTML = '<p class="mini-cart-empty">Your bag is empty. Time to adopt a plant \uD83C\uDF31</p>';
  } else {
    wrap.innerHTML = items.map(function (item) {
      return (
        '<div class="mini-cart-item" data-id="' + item.id + '">' +
          '<img class="mini-cart-item-img" src="' + item.images[0] + '" alt="' + item.name + '">' +
          '<div class="mini-cart-item-info">' +
            '<p class="mini-cart-item-name">' + item.name + '</p>' +
            '<div class="mini-cart-item-meta">' +
              '<span>Qty ' + item.qty + '</span>' +
              '<span>' + formatPrice(item.price * item.qty) + '</span>' +
            '</div>' +
            '<button class="mini-cart-item-remove" data-remove="' + item.id + '">Remove</button>' +
          '</div>' +
        '</div>'
      );
    }).join("");
  }

  if (subtotalEl) {
    subtotalEl.textContent = formatPrice(Cart.subtotal());
  }

  wrap.querySelectorAll("[data-remove]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      Cart.remove(btn.getAttribute("data-remove"));
      renderMiniCartItems();
      refreshHeaderCounts();
      if (typeof window.onCartChanged === "function") {
        window.onCartChanged();
      }
    });
  });
}

/* -------------------- TOAST -------------------- */
let toastTimer = null;
function showToast(message) {
  let toast = document.getElementById("globalToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "globalToast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    toast.classList.remove("is-visible");
  }, 2600);
}

/* -------------------- SHARED PRODUCT CARD RENDERER -------------------- */
/* Used by home.js, shop.js and product.js (related products) so every
   page renders product cards the exact same way. */
function heartSvg() {
  return '<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9.3C0.3 8.2 2 4.5 5.7 4c2-0.3 3.9 0.7 5 2.3C11.8 4.7 13.7 3.7 15.7 4c3.7 0.5 5.4 4.2 3.7 7.7C19.5 16.4 12 21 12 21z"></path></svg>';
}

function productCardHTML(product) {
  const badge = product.badge
    ? '<span class="product-card-badge">' + product.badge + '</span>'
    : "";
  const oldPrice = product.oldPrice
    ? '<span class="price-old">' + formatPrice(product.oldPrice) + '</span>'
    : "";
  const wishActive = Wishlist.has(product.id) ? " is-active" : "";

  return (
    '<article class="product-card" data-id="' + product.id + '">' +
      '<div class="product-card-media">' +
        badge +
        '<button class="icon-btn product-card-wishlist' + wishActive + '" data-wishlist="' + product.id + '" aria-label="Add to wishlist">' +
          heartSvg() +
        '</button>' +
        '<a href="product.html?id=' + product.id + '">' +
          '<img class="product-card-img" src="' + product.images[0] + '" alt="' + product.name + '">' +
        '</a>' +
        '<div class="product-card-actions">' +
          '<button class="btn btn-primary btn-sm btn-block" data-addcart="' + product.id + '">Add to Bag</button>' +
        '</div>' +
      '</div>' +
      '<p class="product-card-category">' + product.category + '</p>' +
      '<a href="product.html?id=' + product.id + '"><h3 class="product-card-title">' + product.name + '</h3></a>' +
      '<div class="product-card-rating"><span class="stars">' + starString(product.rating) + '</span><span>(' + product.reviews + ')</span></div>' +
      '<div class="product-card-price-row"><span class="price">' + formatPrice(product.price) + '</span>' + oldPrice + '</div>' +
    '</article>'
  );
}

function attachProductCardEvents(scopeEl) {
  scopeEl.querySelectorAll("[data-wishlist]").forEach(function (btn) {
    bindWishlistButton(btn, btn.getAttribute("data-wishlist"));
  });
  scopeEl.querySelectorAll("[data-addcart]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const id = btn.getAttribute("data-addcart");
      Cart.add(id, 1);
      refreshHeaderCounts();
      bumpBadge(document.getElementById("cartCount"));
      renderMiniCartItems();
      showToast(findProduct(id).name + " added to bag");
    });
  });
}

/* -------------------- WISHLIST TOGGLE (shared button behaviour) -------------------- */
function bindWishlistButton(btn, productId) {
  if (Wishlist.has(productId)) {
    btn.classList.add("is-active");
  }
  btn.addEventListener("click", function (e) {
    e.preventDefault();
    const isNowActive = Wishlist.toggle(productId);
    btn.classList.toggle("is-active", isNowActive);
    refreshHeaderCounts();
    bumpBadge(document.getElementById("wishlistCount"));
    showToast(isNowActive ? "Added to wishlist" : "Removed from wishlist");
  });
}

/* -------------------- NEWSLETTER FORM -------------------- */
function initNewsletterForm() {
  const form = document.getElementById("newsletterForm");
  if (!form) return;
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const msg = form.querySelector(".form-success-msg");
    if (msg) {
      msg.classList.add("is-visible");
    }
    form.reset();
    showToast("Subscribed! Watch your inbox for plant tips.");
  });
}
