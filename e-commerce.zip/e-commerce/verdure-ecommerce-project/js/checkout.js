/* =========================================================
   VERDURE — CHECKOUT PAGE SCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  renderCheckoutSummary();
  initPaymentMethodToggle();
  initCheckoutForm();

  if (Cart.items().length === 0) {
    const form = document.getElementById("checkoutForm");
    if (form) form.style.display = "none";
    const empty = document.getElementById("checkoutEmptyState");
    if (empty) empty.style.display = "block";
  }
});

function renderCheckoutSummary() {
  const wrap = document.getElementById("checkoutItems");
  if (!wrap) return;

  const items = Cart.items();
  wrap.innerHTML = items.map(function (item) {
    return (
      '<div class="checkout-mini-item">' +
        '<img src="' + item.images[0] + '" alt="' + item.name + '">' +
        '<div>' +
          '<p class="checkout-mini-item-name">' + item.name + '</p>' +
          '<p class="checkout-mini-item-qty">Qty ' + item.qty + '</p>' +
        '</div>' +
        '<span class="checkout-mini-item-price">' + formatPrice(item.price * item.qty) + '</span>' +
      '</div>'
    );
  }).join("");

  const subtotal = Cart.subtotal();
  const shipping = subtotal >= 1999 || subtotal === 0 ? 0 : 99;
  const total = subtotal + shipping;

  setText("checkoutSubtotal", formatPrice(subtotal));
  setText("checkoutShipping", shipping === 0 ? "Free" : formatPrice(shipping));
  setText("checkoutTotal", formatPrice(total));
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

/* -------------------- PAYMENT METHOD TOGGLE -------------------- */
function initPaymentMethodToggle() {
  const radios = document.querySelectorAll('input[name="paymentMethod"]');
  const cardFields = document.getElementById("cardFields");
  const upiFields = document.getElementById("upiFields");

  function update() {
    const selected = document.querySelector('input[name="paymentMethod"]:checked');
    const value = selected ? selected.value : "cod";
    if (cardFields) cardFields.classList.toggle("is-visible", value === "card");
    if (upiFields) upiFields.classList.toggle("is-visible", value === "upi");
  }

  radios.forEach(function (radio) {
    radio.addEventListener("change", update);
  });
  update();
}

/* -------------------- FORM VALIDATION + SUBMIT -------------------- */
function initCheckoutForm() {
  const form = document.getElementById("checkoutForm");
  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    let valid = true;

    form.querySelectorAll("[required]").forEach(function (field) {
      /* skip validating hidden conditional fields */
      const conditionalParent = field.closest(".conditional-fields");
      if (conditionalParent && !conditionalParent.classList.contains("is-visible")) {
        return;
      }
      const group = field.closest(".form-group");
      const filled = field.value.trim().length > 0;
      const emailOk = field.type !== "email" || /^\S+@\S+\.\S+$/.test(field.value.trim());

      if (!filled || !emailOk) {
        valid = false;
        if (group) group.classList.add("has-error");
      } else if (group) {
        group.classList.remove("has-error");
      }
    });

    if (!valid) {
      showToast("Please fill in the highlighted fields");
      return;
    }

    const order = {
      orderNumber: "VRD" + Math.floor(100000 + Math.random() * 900000),
      items: Cart.items(),
      subtotal: Cart.subtotal(),
      placedAt: new Date().toISOString(),
      name: document.getElementById("fullName") ? document.getElementById("fullName").value : ""
    };
    Store.saveLastOrder(order);
    Cart.clear();

    window.location.href = "thank-you.html";
  });
}
