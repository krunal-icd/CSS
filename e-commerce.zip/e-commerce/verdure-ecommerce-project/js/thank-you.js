/* =========================================================
   VERDURE — THANK YOU PAGE SCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const order = Store.getLastOrder();
  const orderNumberEl = document.getElementById("orderNumber");
  const recapEl = document.getElementById("orderRecap");
  const recapWrap = document.getElementById("orderRecapWrap");

  if (!order) {
    if (recapWrap) recapWrap.style.display = "none";
    if (orderNumberEl) orderNumberEl.textContent = "N/A";
    return;
  }

  if (orderNumberEl) {
    orderNumberEl.textContent = order.orderNumber;
  }

  if (recapEl) {
    recapEl.innerHTML = order.items.map(function (item) {
      return (
        '<div class="checkout-mini-item">' +
          '<img src="' + item.images[0] + '" alt="' + item.name + '">' +
          '<div>' +
            '<p class="checkout-mini-item-name">' + item.name + '</p>' +
            '<p class="checkout-mini-item-qty">Qty ' + item.qty + '</p>' +
          '</div>' +
          '<span class="checkout-mini-item-price">' + formatPrice(item.price * item.qty) + '</span>' +
        '</div>'
      );
    }).join("") +
    '<div class="summary-row total-row"><span>Total paid</span><span>' + formatPrice(order.subtotal) + '</span></div>';
  }
});
