/* =========================================================
   VERDURE — PRODUCT DATA + CART / WISHLIST STATE
   Data is stored in localStorage so it persists between pages.
   (Images are placeholder photos from picsum.photos — swap the
   URLs for your own product photography in a real project.)
   ========================================================= */

const PRODUCTS = [
  {
    id: "p1",
    name: "Monstera Deliciosa",
    category: "plants",
    price: 1499,
    oldPrice: 1799,
    rating: 4.8,
    reviews: 132,
    badge: "Sale",
    stock: 18,
    desc: "A statement Swiss-cheese plant with dramatic split leaves. Thrives in bright, indirect light and forgives the occasional missed watering.",
    images: [
      "https://picsum.photos/seed/monstera1/700/700",
      "https://picsum.photos/seed/monstera2/700/700",
      "https://picsum.photos/seed/monstera3/700/700",
      "https://picsum.photos/seed/monstera4/700/700"
    ]
  },
  {
    id: "p2",
    name: "Snake Plant",
    category: "plants",
    price: 899,
    oldPrice: null,
    rating: 4.6,
    reviews: 88,
    badge: null,
    stock: 32,
    desc: "Nearly indestructible and air-purifying, the snake plant is happy in low light and needs watering only once every few weeks.",
    images: [
      "https://picsum.photos/seed/snakeplant1/700/700",
      "https://picsum.photos/seed/snakeplant2/700/700",
      "https://picsum.photos/seed/snakeplant3/700/700"
    ]
  },
  {
    id: "p3",
    name: "Fiddle Leaf Fig",
    category: "plants",
    price: 2199,
    oldPrice: 2599,
    rating: 4.4,
    reviews: 61,
    badge: "Sale",
    stock: 9,
    desc: "Large violin-shaped leaves make this a favourite living-room centrepiece. Prefers a consistent spot with bright, filtered light.",
    images: [
      "https://picsum.photos/seed/fiddleleaf1/700/700",
      "https://picsum.photos/seed/fiddleleaf2/700/700",
      "https://picsum.photos/seed/fiddleleaf3/700/700"
    ]
  },
  {
    id: "p4",
    name: "Ribbed Ceramic Planter",
    category: "planters",
    price: 749,
    oldPrice: null,
    rating: 4.7,
    reviews: 54,
    badge: "New",
    stock: 40,
    desc: "Hand-finished stoneware planter with a soft ribbed texture and a drainage hole plus saucer, sized for medium houseplants.",
    images: [
      "https://picsum.photos/seed/ceramicpot1/700/700",
      "https://picsum.photos/seed/ceramicpot2/700/700",
      "https://picsum.photos/seed/ceramicpot3/700/700"
    ]
  },
  {
    id: "p5",
    name: "Terracotta Pot Set of 3",
    category: "planters",
    price: 599,
    oldPrice: 699,
    rating: 4.5,
    reviews: 76,
    badge: "Sale",
    stock: 25,
    desc: "Three classic unglazed terracotta pots in graduating sizes — breathable clay that keeps roots healthy and dry between waterings.",
    images: [
      "https://picsum.photos/seed/terracotta1/700/700",
      "https://picsum.photos/seed/terracotta2/700/700",
      "https://picsum.photos/seed/terracotta3/700/700"
    ]
  },
  {
    id: "p6",
    name: "Macrame Plant Hanger",
    category: "accessories",
    price: 449,
    oldPrice: null,
    rating: 4.9,
    reviews: 41,
    badge: null,
    stock: 60,
    desc: "Hand-knotted 100% cotton hanger that suspends a pot beautifully by any window — an easy way to add greenery without using floor space.",
    images: [
      "https://picsum.photos/seed/macrame1/700/700",
      "https://picsum.photos/seed/macrame2/700/700"
    ]
  },
  {
    id: "p7",
    name: "Brass Watering Can",
    category: "accessories",
    price: 899,
    oldPrice: null,
    rating: 4.6,
    reviews: 29,
    badge: null,
    stock: 22,
    desc: "A 1.2-litre solid brass watering can with a long, narrow spout for precise watering of both small pots and hanging planters.",
    images: [
      "https://picsum.photos/seed/wateringcan1/700/700",
      "https://picsum.photos/seed/wateringcan2/700/700"
    ]
  },
  {
    id: "p8",
    name: "Plant Care Starter Kit",
    category: "kits",
    price: 1299,
    oldPrice: 1499,
    rating: 4.7,
    reviews: 37,
    badge: "Sale",
    stock: 15,
    desc: "Everything a new plant parent needs: pruning snips, a mister, moisture meter and a printed care guide for 20 popular houseplants.",
    images: [
      "https://picsum.photos/seed/carekit1/700/700",
      "https://picsum.photos/seed/carekit2/700/700",
      "https://picsum.photos/seed/carekit3/700/700"
    ]
  },
  {
    id: "p9",
    name: "Peace Lily",
    category: "plants",
    price: 999,
    oldPrice: null,
    rating: 4.5,
    reviews: 95,
    badge: null,
    stock: 27,
    desc: "Glossy leaves and elegant white blooms, and it tells you exactly when it's thirsty by drooping slightly. Great for low-light rooms.",
    images: [
      "https://picsum.photos/seed/peacelily1/700/700",
      "https://picsum.photos/seed/peacelily2/700/700",
      "https://picsum.photos/seed/peacelily3/700/700"
    ]
  },
  {
    id: "p10",
    name: "Areca Palm",
    category: "plants",
    price: 1899,
    oldPrice: null,
    rating: 4.3,
    reviews: 22,
    badge: "New",
    stock: 12,
    desc: "Feathery, arching fronds bring an instant resort feel to any corner. One of the best natural humidifiers for indoor air.",
    images: [
      "https://picsum.photos/seed/arecapalm1/700/700",
      "https://picsum.photos/seed/arecapalm2/700/700"
    ]
  },
  {
    id: "p11",
    name: "Round Concrete Planter",
    category: "planters",
    price: 649,
    oldPrice: null,
    rating: 4.4,
    reviews: 18,
    badge: null,
    stock: 34,
    desc: "Minimal, industrial-inspired concrete planter with a matte finish that pairs well with both trailing and upright plants.",
    images: [
      "https://picsum.photos/seed/concretepot1/700/700",
      "https://picsum.photos/seed/concretepot2/700/700"
    ]
  },
  {
    id: "p12",
    name: "Precision Pruning Shears",
    category: "accessories",
    price: 399,
    oldPrice: 499,
    rating: 4.8,
    reviews: 66,
    badge: "Sale",
    stock: 48,
    desc: "Sharp, spring-loaded stainless-steel shears sized for houseplants — clean cuts that heal fast and keep growth looking tidy.",
    images: [
      "https://picsum.photos/seed/shears1/700/700",
      "https://picsum.photos/seed/shears2/700/700"
    ]
  }
];

/* -------------------- STORAGE HELPERS -------------------- */
const Store = {
  getCart() {
    try {
      return JSON.parse(localStorage.getItem("verdure_cart")) || [];
    } catch (e) {
      return [];
    }
  },
  saveCart(cart) {
    localStorage.setItem("verdure_cart", JSON.stringify(cart));
  },
  getWishlist() {
    try {
      return JSON.parse(localStorage.getItem("verdure_wishlist")) || [];
    } catch (e) {
      return [];
    }
  },
  saveWishlist(list) {
    localStorage.setItem("verdure_wishlist", JSON.stringify(list));
  },
  getLastOrder() {
    try {
      return JSON.parse(localStorage.getItem("verdure_last_order")) || null;
    } catch (e) {
      return null;
    }
  },
  saveLastOrder(order) {
    localStorage.setItem("verdure_last_order", JSON.stringify(order));
  }
};

function findProduct(id) {
  return PRODUCTS.find(function (p) { return p.id === id; });
}

function formatPrice(n) {
  return "\u20B9" + Number(n).toLocaleString("en-IN");
}

function starString(rating) {
  const full = Math.round(rating);
  let out = "";
  for (let i = 0; i < 5; i++) {
    out += i < full ? "\u2605" : "\u2606";
  }
  return out;
}

/* -------------------- CART OPERATIONS -------------------- */
const Cart = {
  add(productId, qty) {
    qty = qty || 1;
    const cart = Store.getCart();
    const existing = cart.find(function (item) { return item.id === productId; });
    if (existing) {
      existing.qty += qty;
    } else {
      cart.push({ id: productId, qty: qty });
    }
    Store.saveCart(cart);
  },
  remove(productId) {
    let cart = Store.getCart();
    cart = cart.filter(function (item) { return item.id !== productId; });
    Store.saveCart(cart);
  },
  setQty(productId, qty) {
    const cart = Store.getCart();
    const item = cart.find(function (i) { return i.id === productId; });
    if (item) {
      item.qty = Math.max(1, qty);
      Store.saveCart(cart);
    }
  },
  clear() {
    Store.saveCart([]);
  },
  items() {
    return Store.getCart()
      .map(function (item) {
        const product = findProduct(item.id);
        if (!product) return null;
        return Object.assign({}, product, { qty: item.qty });
      })
      .filter(Boolean);
  },
  count() {
    return Store.getCart().reduce(function (sum, item) { return sum + item.qty; }, 0);
  },
  subtotal() {
    return Cart.items().reduce(function (sum, item) { return sum + item.price * item.qty; }, 0);
  }
};

/* -------------------- WISHLIST OPERATIONS -------------------- */
const Wishlist = {
  has(productId) {
    return Store.getWishlist().indexOf(productId) !== -1;
  },
  toggle(productId) {
    let list = Store.getWishlist();
    if (list.indexOf(productId) === -1) {
      list.push(productId);
    } else {
      list = list.filter(function (id) { return id !== productId; });
    }
    Store.saveWishlist(list);
    return Wishlist.has(productId);
  },
  remove(productId) {
    let list = Store.getWishlist();
    list = list.filter(function (id) { return id !== productId; });
    Store.saveWishlist(list);
  },
  items() {
    return Store.getWishlist().map(findProduct).filter(Boolean);
  },
  count() {
    return Store.getWishlist().length;
  }
};
