/* =========================================================
   VERDURE — SHOP / PRODUCT LISTING PAGE SCRIPT
   Handles category filter checkboxes, a max-price range slider
   and a sort dropdown, all applied to PRODUCTS client-side.
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const grid = document.getElementById("productGrid");
  if (!grid) return;

  const checkboxes = document.querySelectorAll(".js-category-filter");
  const priceRange = document.getElementById("priceRange");
  const priceValueEl = document.getElementById("priceRangeValue");
  const sortSelect = document.getElementById("sortSelect");
  const resultCountEl = document.getElementById("shopResultCount");

  function getActiveCategories() {
    const active = [];
    checkboxes.forEach(function (cb) {
      if (cb.checked) active.push(cb.value);
    });
    return active;
  }

  function applyFilters() {
    const activeCategories = getActiveCategories();
    const maxPrice = priceRange ? Number(priceRange.value) : 999999;

    let list = PRODUCTS.filter(function (p) {
      const categoryOk = activeCategories.length === 0 || activeCategories.indexOf(p.category) !== -1;
      const priceOk = p.price <= maxPrice;
      return categoryOk && priceOk;
    });

    const sortValue = sortSelect ? sortSelect.value : "featured";
    if (sortValue === "price-low") {
      list = list.slice().sort(function (a, b) { return a.price - b.price; });
    } else if (sortValue === "price-high") {
      list = list.slice().sort(function (a, b) { return b.price - a.price; });
    } else if (sortValue === "rating") {
      list = list.slice().sort(function (a, b) { return b.rating - a.rating; });
    }

    renderGrid(list);
  }

  function renderGrid(list) {
    if (resultCountEl) {
      resultCountEl.textContent = list.length + " product" + (list.length === 1 ? "" : "s");
    }

    if (list.length === 0) {
      grid.innerHTML =
        '<div class="empty-state">' +
          '<p class="empty-state-emoji">\uD83E\uDEB4</p>' +
          '<h3 class="empty-state-title">No products match your filters</h3>' +
          '<p class="empty-state-desc">Try widening the price range or clearing a category.</p>' +
        '</div>';
      return;
    }

    grid.innerHTML = list.map(productCardHTML).join("");
    attachProductCardEvents(grid);
  }

  checkboxes.forEach(function (cb) {
    cb.addEventListener("change", applyFilters);
  });

  if (priceRange) {
    priceRange.addEventListener("input", function () {
      if (priceValueEl) {
        priceValueEl.textContent = "Up to " + formatPrice(priceRange.value);
      }
      applyFilters();
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener("change", applyFilters);
  }

  /* read ?category= from the URL so homepage category cards can deep-link */
  const params = new URLSearchParams(window.location.search);
  const presetCategory = params.get("category");
  if (presetCategory) {
    checkboxes.forEach(function (cb) {
      cb.checked = cb.value === presetCategory;
    });
  }

  applyFilters();
});
