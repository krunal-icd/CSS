/* =========================================================
   VERDURE — PRODUCT DETAILS PAGE SCRIPT
   Reads ?id= from the URL, renders the product, and wires up
   the image gallery, quantity selector, tabs and the
   "Request a Quote" modal.
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const params = new URLSearchParams(window.location.search);
  const productId = params.get("id") || PRODUCTS[0].id;
  const product = findProduct(productId) || PRODUCTS[0];

  renderProduct(product);
  initGallery(product);
  initQuantitySelector();
  initTabs();
  initAddToQuoteModal(product);
  renderRelatedProducts(product);
});

function renderProduct(product) {
  document.title = product.name + " \u2014 Verdure";

  setText("breadcrumbProductName", product.name);
  setText("productCategory", product.category);
  setText("productCategoryMeta", product.category);
  setText("productTitle", product.name);
  setText("productDesc", product.desc);
  setText("productStock", product.stock > 0 ? "In stock \u2014 ready to ship" : "Out of stock");
  setText("productReviewCount", "(" + product.reviews + " reviews)");

  const starsEl = document.getElementById("productStars");
  if (starsEl) starsEl.textContent = starString(product.rating);

  const priceEl = document.getElementById("productPrice");
  if (priceEl) priceEl.textContent = formatPrice(product.price);

  const oldPriceEl = document.getElementById("productOldPrice");
  if (oldPriceEl) {
    if (product.oldPrice) {
      oldPriceEl.textContent = formatPrice(product.oldPrice);
      oldPriceEl.style.display = "inline";
    } else {
      oldPriceEl.style.display = "none";
    }
  }

  const wishBtn = document.getElementById("productWishlistBtn");
  if (wishBtn) {
    bindWishlistButton(wishBtn, product.id);
  }

  const addCartBtn = document.getElementById("productAddCartBtn");
  if (addCartBtn) {
    addCartBtn.addEventListener("click", function () {
      const qty = Number(document.getElementById("qtyInput").value) || 1;
      Cart.add(product.id, qty);
      refreshHeaderCounts();
      bumpBadge(document.getElementById("cartCount"));
      renderMiniCartItems();
      showToast(qty + " \u00d7 " + product.name + " added to bag");
      window.openMiniCart();
    });
  }
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

/* -------------------- IMAGE GALLERY -------------------- */
function initGallery(product) {
  const mainImg = document.getElementById("galleryMainImg");
  const thumbWrap = document.getElementById("galleryThumbs");
  if (!mainImg || !thumbWrap) return;

  thumbWrap.innerHTML = product.images.map(function (src, i) {
    return '<img class="gallery-thumb' + (i === 0 ? " is-active" : "") + '" src="' + src + '" data-src="' + src + '" alt="' + product.name + ' view ' + (i + 1) + '">';
  }).join("");

  mainImg.src = product.images[0];

  thumbWrap.querySelectorAll(".gallery-thumb").forEach(function (thumb) {
    thumb.addEventListener("click", function () {
      if (thumb.classList.contains("is-active")) return;
      thumbWrap.querySelectorAll(".gallery-thumb").forEach(function (t) {
        t.classList.remove("is-active");
      });
      thumb.classList.add("is-active");

      /* fade-out / swap-src / fade-in using a transition on opacity */
      mainImg.classList.add("is-fading");
      setTimeout(function () {
        mainImg.src = thumb.getAttribute("data-src");
        mainImg.classList.remove("is-fading");
      }, 200);
    });
  });
}

/* -------------------- QUANTITY SELECTOR -------------------- */
function initQuantitySelector() {
  const input = document.getElementById("qtyInput");
  const minusBtn = document.getElementById("qtyMinus");
  const plusBtn = document.getElementById("qtyPlus");
  if (!input) return;

  minusBtn.addEventListener("click", function () {
    input.value = Math.max(1, Number(input.value) - 1);
  });
  plusBtn.addEventListener("click", function () {
    input.value = Number(input.value) + 1;
  });
  input.addEventListener("change", function () {
    if (Number(input.value) < 1 || isNaN(Number(input.value))) {
      input.value = 1;
    }
  });
}

/* -------------------- TABS -------------------- */
function initTabs() {
  const tabButtons = document.querySelectorAll(".tab-btn");
  const panels = document.querySelectorAll(".tab-panel");
  tabButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      tabButtons.forEach(function (b) { b.classList.remove("is-active"); });
      panels.forEach(function (p) { p.classList.remove("is-active"); });
      btn.classList.add("is-active");
      const target = document.getElementById(btn.getAttribute("data-tab"));
      if (target) target.classList.add("is-active");
    });
  });
}

/* -------------------- ADD TO QUOTE MODAL -------------------- */
function initAddToQuoteModal(product) {
  const openBtn = document.getElementById("openQuoteModalBtn");
  const overlay = document.getElementById("quoteModalOverlay");
  const closeBtn = document.getElementById("quoteModalClose");
  const cancelBtn = document.getElementById("quoteModalCancel");
  const form = document.getElementById("quoteForm");
  if (!openBtn || !overlay) return;

  const previewImg = document.getElementById("quoteProductImg");
  const previewName = document.getElementById("quoteProductName");
  const previewPrice = document.getElementById("quoteProductPrice");
  if (previewImg) previewImg.src = product.images[0];
  if (previewName) previewName.textContent = product.name;
  if (previewPrice) previewPrice.textContent = formatPrice(product.price) + " / unit";

  function open() {
    overlay.classList.add("is-open");
  }
  function close() {
    overlay.classList.remove("is-open");
  }

  openBtn.addEventListener("click", open);
  if (closeBtn) closeBtn.addEventListener("click", close);
  if (cancelBtn) cancelBtn.addEventListener("click", close);
  overlay.addEventListener("click", function (e) {
    if (e.target === overlay) close();
  });

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      let valid = true;
      form.querySelectorAll("[required]").forEach(function (field) {
        const group = field.closest(".form-group");
        if (!field.value.trim()) {
          valid = false;
          if (group) group.classList.add("has-error");
        } else if (group) {
          group.classList.remove("has-error");
        }
      });
      if (!valid) return;

      close();
      form.reset();
      showToast("Quote request sent \u2014 we'll email you within 24 hours");
    });
  }
}

/* -------------------- RELATED PRODUCTS -------------------- */
function renderRelatedProducts(product) {
  const wrap = document.getElementById("relatedProducts");
  if (!wrap) return;
  const related = PRODUCTS.filter(function (p) {
    return p.category === product.category && p.id !== product.id;
  }).slice(0, 4);

  if (related.length === 0) {
    wrap.parentElement.style.display = "none";
    return;
  }

  wrap.innerHTML = related.map(productCardHTML).join("");
  attachProductCardEvents(wrap);
}
