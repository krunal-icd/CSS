/* =========================================================
   VERDURE — WISHLIST PAGE SCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  renderWishlistPage();
});

function renderWishlistPage() {
  const listEl = document.getElementById("wishlistList");
  const emptyEl = document.getElementById("wishlistEmptyState");
  if (!listEl) return;

  const items = Wishlist.items();

  if (items.length === 0) {
    listEl.style.display = "none";
    if (emptyEl) emptyEl.style.display = "block";
    return;
  }

  listEl.style.display = "block";
  if (emptyEl) emptyEl.style.display = "none";

  listEl.innerHTML = items.map(function (item) {
    const oldPrice = item.oldPrice ? '<span class="price-old">' + formatPrice(item.oldPrice) + '</span>' : "";
    return (
      '<div class="wishlist-row" data-id="' + item.id + '">' +
        '<a href="product.html?id=' + item.id + '"><img src="' + item.images[0] + '" alt="' + item.name + '"></a>' +
        '<div class="wishlist-info">' +
          '<p class="product-card-category">' + item.category + '</p>' +
          '<a href="product.html?id=' + item.id + '"><h3 class="product-card-title">' + item.name + '</h3></a>' +
          '<div class="product-card-price-row"><span class="price">' + formatPrice(item.price) + '</span>' + oldPrice + '</div>' +
        '</div>' +
        '<div class="wishlist-actions">' +
          '<button class="btn btn-primary btn-sm" data-addcart="' + item.id + '">Add to Bag</button>' +
          '<button class="icon-btn wishlist-remove-btn" data-remove="' + item.id + '" aria-label="Remove from wishlist">\u2715</button>' +
        '</div>' +
      '</div>'
    );
  }).join("");

  listEl.querySelectorAll("[data-addcart]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const id = btn.getAttribute("data-addcart");
      Cart.add(id, 1);
      refreshHeaderCounts();
      bumpBadge(document.getElementById("cartCount"));
      renderMiniCartItems();
      showToast(findProduct(id).name + " added to bag");
    });
  });

  listEl.querySelectorAll("[data-remove]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const id = btn.getAttribute("data-remove");
      const row = document.querySelector('.wishlist-row[data-id="' + id + '"]');
      if (row) {
        row.classList.add("is-removing");
        setTimeout(function () {
          Wishlist.remove(id);
          refreshHeaderCounts();
          renderWishlistPage();
        }, 280);
      }
    });
  });
}
