/* =========================================================
   VERDURE — CART PAGE SCRIPT
   ========================================================= */

const SHIPPING_FLAT = 99;
const FREE_SHIPPING_THRESHOLD = 1999;
let appliedCoupon = null;

document.addEventListener("DOMContentLoaded", function () {
  renderCartPage();
  initCoupon();
  window.onCartChanged = renderCartPage;
});

function renderCartPage() {
  const listEl = document.getElementById("cartList");
  const emptyEl = document.getElementById("cartEmptyState");
  const layoutEl = document.getElementById("cartLayout");
  if (!listEl) return;

  const items = Cart.items();

  if (items.length === 0) {
    if (layoutEl) layoutEl.style.display = "none";
    if (emptyEl) emptyEl.style.display = "block";
    return;
  }

  if (layoutEl) layoutEl.style.display = "flex";
  if (emptyEl) emptyEl.style.display = "none";

  listEl.innerHTML = items.map(function (item) {
    return (
      '<div class="cart-row" data-id="' + item.id + '">' +
        '<div class="cart-col-product">' +
          '<img src="' + item.images[0] + '" alt="' + item.name + '">' +
          '<div>' +
            '<p class="cart-item-name">' + item.name + '</p>' +
            '<p class="product-card-category">' + item.category + '</p>' +
            '<button class="cart-item-remove" data-remove="' + item.id + '">Remove</button>' +
          '</div>' +
        '</div>' +
        '<div class="cart-col-qty">' +
          '<div class="qty-selector">' +
            '<button class="qty-btn" data-qty-minus="' + item.id + '">\u2212</button>' +
            '<input class="qty-input" type="number" min="1" value="' + item.qty + '" data-qty-input="' + item.id + '">' +
            '<button class="qty-btn" data-qty-plus="' + item.id + '">+</button>' +
          '</div>' +
        '</div>' +
        '<div class="cart-col-price"><span class="price">' + formatPrice(item.price) + '</span></div>' +
        '<div class="cart-col-total"><span class="price">' + formatPrice(item.price * item.qty) + '</span></div>' +
      '</div>'
    );
  }).join("");

  bindCartRowEvents();
  renderSummary();
}

function bindCartRowEvents() {
  document.querySelectorAll("[data-remove]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const id = btn.getAttribute("data-remove");
      const row = document.querySelector('.cart-row[data-id="' + id + '"]');
      if (row) {
        row.classList.add("is-removing");
        setTimeout(function () {
          Cart.remove(id);
          renderCartPage();
          refreshHeaderCounts();
          renderMiniCartItems();
        }, 280);
      }
    });
  });

  document.querySelectorAll("[data-qty-minus]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const id = btn.getAttribute("data-qty-minus");
      const current = Cart.items().find(function (i) { return i.id === id; });
      if (current) {
        Cart.setQty(id, Math.max(1, current.qty - 1));
        renderCartPage();
        refreshHeaderCounts();
        renderMiniCartItems();
      }
    });
  });

  document.querySelectorAll("[data-qty-plus]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const id = btn.getAttribute("data-qty-plus");
      const current = Cart.items().find(function (i) { return i.id === id; });
      if (current) {
        Cart.setQty(id, current.qty + 1);
        renderCartPage();
        refreshHeaderCounts();
        renderMiniCartItems();
      }
    });
  });

  document.querySelectorAll("[data-qty-input]").forEach(function (input) {
    input.addEventListener("change", function () {
      const id = input.getAttribute("data-qty-input");
      const val = Math.max(1, Number(input.value) || 1);
      Cart.setQty(id, val);
      renderCartPage();
      refreshHeaderCounts();
      renderMiniCartItems();
    });
  });
}

function renderSummary() {
  const subtotal = Cart.subtotal();
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD || subtotal === 0 ? 0 : SHIPPING_FLAT;
  const discount = appliedCoupon ? Math.round(subtotal * appliedCoupon.percent / 100) : 0;
  const total = Math.max(0, subtotal + shipping - discount);

  setSummaryText("summarySubtotal", formatPrice(subtotal));
  setSummaryText("summaryShipping", shipping === 0 ? "Free" : formatPrice(shipping));
  setSummaryText("summaryTotal", formatPrice(total));

  const discountRow = document.getElementById("summaryDiscountRow");
  if (discountRow) {
    if (discount > 0) {
      discountRow.style.display = "flex";
      setSummaryText("summaryDiscount", "\u2212" + formatPrice(discount));
    } else {
      discountRow.style.display = "none";
    }
  }
}

function setSummaryText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function initCoupon() {
  const applyBtn = document.getElementById("couponApplyBtn");
  const input = document.getElementById("couponInput");
  const msg = document.getElementById("couponMsg");
  if (!applyBtn || !input) return;

  applyBtn.addEventListener("click", function () {
    const code = input.value.trim().toUpperCase();
    if (code === "VERDURE10") {
      appliedCoupon = { code: code, percent: 10 };
      if (msg) {
        msg.textContent = "10% coupon applied!";
        msg.style.color = "var(--color-success)";
      }
    } else {
      appliedCoupon = null;
      if (msg) {
        msg.textContent = "Invalid code. Try VERDURE10.";
        msg.style.color = "var(--color-error)";
      }
    }
    renderSummary();
  });
}
