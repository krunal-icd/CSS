/* =========================================================
   VERDURE — CONTACT PAGE SCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    let valid = true;

    form.querySelectorAll("[required]").forEach(function (field) {
      const group = field.closest(".form-group");
      const filled = field.value.trim().length > 0;
      const emailOk = field.type !== "email" || /^\S+@\S+\.\S+$/.test(field.value.trim());

      if (!filled || !emailOk) {
        valid = false;
        if (group) group.classList.add("has-error");
      } else if (group) {
        group.classList.remove("has-error");
      }
    });

    if (!valid) {
      showToast("Please fill in the highlighted fields");
      return;
    }

    const successMsg = document.getElementById("contactSuccessMsg");
    if (successMsg) {
      successMsg.classList.add("is-visible");
    }
    form.reset();
    showToast("Message sent \u2014 we'll reply within a day");
  });
});
