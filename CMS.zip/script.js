// Ridgeline Press — shared behaviour
// Mobile nav toggle, FAQ accordion, portfolio filter.
// Plain JS, no build step — kept simple on purpose so it's easy
// to trace which markup each piece of behaviour is attached to.

document.addEventListener('DOMContentLoaded', function () {

  /* ---- mobile nav ---- */
  var toggle = document.querySelector('.nav-toggle');
  var navList = document.querySelector('.nav-list');
  if (toggle && navList) {
    toggle.addEventListener('click', function () {
      var isOpen = navList.getAttribute('data-open') === 'true';
      navList.setAttribute('data-open', String(!isOpen));
      navList.style.display = isOpen ? 'none' : 'flex';
      toggle.setAttribute('aria-expanded', String(!isOpen));
    });
  }

  /* ---- FAQ accordion ---- */
  var triggers = document.querySelectorAll('.accordion-trigger');
  triggers.forEach(function (trigger) {
    trigger.addEventListener('click', function () {
      var item = trigger.closest('.accordion-item');
      var isOpen = item.getAttribute('data-open') === 'true';

      // close sibling panels within the same accordion group
      var group = item.parentElement;
      group.querySelectorAll('.accordion-item').forEach(function (sibling) {
        sibling.setAttribute('data-open', 'false');
        sibling.querySelector('.accordion-trigger').setAttribute('aria-expanded', 'false');
      });

      item.setAttribute('data-open', String(!isOpen));
      trigger.setAttribute('aria-expanded', String(!isOpen));
    });
  });

  /* ---- portfolio filter ---- */
  var filterButtons = document.querySelectorAll('.filter-btn');
  var portfolioItems = document.querySelectorAll('.portfolio-item');
  filterButtons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      filterButtons.forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
      btn.setAttribute('aria-pressed', 'true');
      var category = btn.getAttribute('data-filter');

      portfolioItems.forEach(function (item) {
        var match = category === 'all' || item.getAttribute('data-category') === category;
        item.style.display = match ? '' : 'none';
      });
    });
  });

  /* ---- contact form (front-end only, no backend wired up) ---- */
  var contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var status = contactForm.querySelector('.form-status');
      if (status) {
        status.textContent = 'Thanks — this is a static demo, so nothing was actually sent.';
      }
    });
  }
});
